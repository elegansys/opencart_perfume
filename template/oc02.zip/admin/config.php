<?php
// HTTP
define('HTTP_SERVER', 'https://opencart.multipurposethemes.com/perfume/oc02/admin/');
define('HTTP_CATALOG', 'https://opencart.multipurposethemes.com/perfume/oc02/');

// HTTPS
define('HTTPS_SERVER', 'https://opencart.multipurposethemes.com/perfume/oc02/admin/');
define('HTTPS_CATALOG', 'https://opencart.multipurposethemes.com/perfume/oc02/');

// DIR
define('DIR_APPLICATION', '/home/openmultipur/public_html/perfume/oc02/admin/');
define('DIR_SYSTEM', '/home/openmultipur/public_html/perfume/oc02/system/');
define('DIR_IMAGE', '/home/openmultipur/public_html/perfume/oc02/image/');
define('DIR_STORAGE', '/home/openmultipur/public_html/perfume/oc02/storage/');
define('DIR_CATALOG', '/home/openmultipur/public_html/perfume/oc02/catalog/');
define('DIR_LANGUAGE', DIR_APPLICATION . 'language/');
define('DIR_TEMPLATE', DIR_APPLICATION . 'view/template/');
define('DIR_CONFIG', DIR_SYSTEM . 'config/');
define('DIR_CACHE', DIR_STORAGE . 'cache/');
define('DIR_DOWNLOAD', DIR_STORAGE . 'download/');
define('DIR_LOGS', DIR_STORAGE . 'logs/');
define('DIR_MODIFICATION', DIR_STORAGE . 'modification/');
define('DIR_SESSION', DIR_STORAGE . 'session/');
define('DIR_UPLOAD', DIR_STORAGE . 'upload/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'openmult_any');
define('DB_PASSWORD', 'openmult_any#2017');
define('DB_DATABASE', 'openmult_oc047_2');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');

// OpenCart API
define('OPENCART_SERVER', 'https://www.opencart.com/');
